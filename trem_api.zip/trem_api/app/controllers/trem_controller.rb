class TremController < ApplicationController
  VELOCIDADE_KMH = 40.0
  VELOCIDADE_MPS = VELOCIDADE_KMH * 1000 / 3600.0 

  def posicao_atual
  pontos = [
    { nome: "São Francisco do Sul", lat: -26.24300, lng: -48.63520 },
    { nome: "São Francisco do Sul", lat: -26.24518, lng: -48.63416 },
    { nome: "São Francisco do Sul", lat: -26.24694, lng: -48.63499 },
    { nome: "São Francisco do Sul", lat: -26.25062, lng: -48.64170 },
    { nome: "São Francisco do Sul", lat: -26.25872, lng: -48.64560 },
    { nome: "São Francisco do Sul", lat: -26.258712, lng: -48.645606 },
    { nome: "São Francisco do Sul", lat: -26.261662, lng: -48.645978 },
    { nome: "São Francisco do Sul", lat: -26.261737, lng: -48.645960 },
    { nome: "São Francisco do Sul", lat: -26.261914, lng: -48.645921 },
    { nome: "São Francisco do Sul", lat: -26.262131, lng: -48.645889 },
    { nome: "São Francisco do Sul", lat: -26.262461, lng: -48.645733 },
    { nome: "São Francisco do Sul", lat: -26.262567, lng: -48.645728 },
    { nome: "São Francisco do Sul", lat: -26.262716, lng: -48.645653 },
    { nome: "São Francisco do Sul", lat: -26.262913, lng: -48.645530 },
    { nome: "São Francisco do Sul", lat: -26.263202, lng: -48.646170 },
    { nome: "São Francisco do Sul", lat: -26.263158, lng: -48.645350 },
    { nome: "São Francisco do Sul", lat: -26.264322, lng: -48.644127 },
    { nome: "São Francisco do Sul", lat: -26.264534, lng: -48.644009 },
    { nome: "São Francisco do Sul", lat: -26.264669, lng: -48.643778 },
    { nome: "São Francisco do Sul", lat: -26.264842, lng: -48.643698 },
    { nome: "São Francisco do Sul", lat: -26.265078, lng: -48.643349 },
    { nome: "São Francisco do Sul", lat: -26.265246, lng: -48.643296 },
    { nome: "São Francisco do Sul", lat: -26.265593, lng: -48.642824 },
    { nome: "São Francisco do Sul", lat: -26.266237, lng: -48.642158 },
    { nome: "São Francisco do Sul", lat: -26.266535, lng: -48.641960 },
    { nome: "São Francisco do Sul", lat: -26.266781, lng: -48.641869 },
    { nome: "São Francisco do Sul", lat: -26.269855, lng: -48.641440 },
    { nome: "São Francisco do Sul", lat: -26.270311, lng: -48.641276 },
    { nome: "São Francisco do Sul", lat: -26.270455, lng: -48.641244 },
    { nome: "São Francisco do Sul", lat: -26.270801, lng: -48.641254 },
    { nome: "São Francisco do Sul", lat: -26.270917, lng: -48.641249 },
    { nome: "São Francisco do Sul", lat: -26.271119, lng: -48.641233 },
    { nome: "São Francisco do Sul", lat: -26.271133, lng: -48.641227 },
    { nome: "São Francisco do Sul", lat: -26.271244, lng: -48.641201 },
    { nome: "São Francisco do Sul", lat: -26.271379, lng: -48.641228 },
    { nome: "São Francisco do Sul", lat: -26.271677, lng: -48.641174 },
    { nome: "São Francisco do Sul", lat: -26.274464, lng: -48.640814 },   
    { nome: "Joinville", lat: -26.3044, lng: -48.8488 },
    { nome: "Guaramirim", lat: -26.2833, lng: -48.9588 },
    { nome: "Jaraguá do Sul", lat: -26.4856, lng: -49.0702 }
  ]

  agora = Time.now
  ultimo_tempo = Rails.cache.fetch(:ultimo_tempo) { agora }
  delta_tempo = agora - ultimo_tempo
  Rails.cache.write(:ultimo_tempo, agora)

  distancia_total = Rails.cache.fetch(:distancia_total) { 0.0 }
  distancia_total += VELOCIDADE_MPS * delta_tempo


  distancia_maxima = pontos.each_cons(2).map { |a, b| haversine(a[:lat], a[:lng], b[:lat], b[:lng]) }.sum


  distancia_total = [distancia_total, distancia_maxima].min

  Rails.cache.write(:distancia_total, distancia_total)

  distancia_percorrida = distancia_total
  ponto_atual = pontos.first
  proximo_ponto = pontos[1]

  distancia_entre_pontos = pontos.each_cons(2).map do |a, b|
    haversine(a[:lat], a[:lng], b[:lat], b[:lng])
  end

  pontos.each_cons(2).with_index do |(inicio, fim), i|
    d = distancia_entre_pontos[i]
    if distancia_percorrida < d
      ponto_atual = inicio
      proximo_ponto = fim
      break
    else
      distancia_percorrida -= d
    end
  end

  d_segmento = haversine(ponto_atual[:lat], ponto_atual[:lng], proximo_ponto[:lat], proximo_ponto[:lng])
  f = [distancia_percorrida / d_segmento, 1.0].min

  lat = ponto_atual[:lat] + (proximo_ponto[:lat] - ponto_atual[:lat]) * f
  lng = ponto_atual[:lng] + (proximo_ponto[:lng] - ponto_atual[:lng]) * f

  progresso_total = (distancia_total / distancia_maxima) * 100

  if progresso_total >= 100
    status = "Chegou ao destino"
    lat = pontos.last[:lat]
    lng = pontos.last[:lng]
    proximo_ponto_nome = "Fim da linha"
    progresso_total = 100
  else
    status = "Em movimento"
    proximo_ponto_nome = proximo_ponto[:nome]
  end

  render json: {
    latitude: lat,
    longitude: lng,
    proximo_ponto: proximo_ponto_nome,
    status: status,
    progresso: progresso_total.round(2)
  }
end


  private

  def haversine(lat1, lon1, lat2, lon2)
    rad_per_deg = Math::PI / 180
    rkm = 6371 
    dlat_rad = (lat2 - lat1) * rad_per_deg
    dlon_rad = (lon2 - lon1) * rad_per_deg

    lat1_rad = lat1 * rad_per_deg
    lat2_rad = lat2 * rad_per_deg

    a = Math.sin(dlat_rad / 2)**2 + Math.cos(lat1_rad) * Math.cos(lat2_rad) * Math.sin(dlon_rad / 2)**2
    c = 2 * Math::atan2(Math::sqrt(a), Math::sqrt(1 - a))

    rkm * c * 1000 
  end

  def resetar
    Rails.cache.delete(:horario_saida)
    Rails.cache.delete(:ultimo_tempo)
    Rails.cache.delete(:distancia_total)
    render json: { status: "Trem resetado com sucesso." }
  end
end
