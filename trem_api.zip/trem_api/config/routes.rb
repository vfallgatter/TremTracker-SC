Rails.application.routes.draw do
  get "/posicao", to: "trem#posicao_atual"
  post "/resetar", to: "trem#resetar"
end
